//
//  ViewController.swift
//  tap counter
//
//  Created by Agrium AMS on 03/06/19.
//  Copyright © 2019 TCS. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
  
    @IBOutlet weak var lockButton: UIButton!
    var tempLock: Bool = true
    
    @IBOutlet weak var UndoButton: UIButton!
    
    @IBOutlet weak var saveButton: UIButton!
    
    @IBOutlet weak var resetButton: UIButton!
    @IBOutlet weak var label: UILabel!
    var myVariable = 0
    
    
    @IBOutlet weak var clickView: UIView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        label.layer.masksToBounds = true
        label.layer.cornerRadius = 10.0
        
        lockButton.layer.masksToBounds = true
        lockButton.layer.cornerRadius = 5.0
        
        UndoButton.layer.masksToBounds = true
        UndoButton.layer.cornerRadius = 5.0
        
        saveButton.layer.masksToBounds = true
        saveButton.layer.cornerRadius = 5.0
        
        resetButton.layer.masksToBounds = true
        resetButton.layer.cornerRadius = 5.0
        
        label.isUserInteractionEnabled = true // Remember to do this
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(
            target: self, action: #selector(didTapLabelDemo))
        label.addGestureRecognizer(tap)
        tap.delegate = self as? UIGestureRecognizerDelegate
    }
    @objc func didTapLabelDemo(sender:UITapGestureRecognizer) {
            print("tap working")
    
        myVariable += 1
      label.text = String(myVariable)
      
    }
    
        // Do any additional setup after loading the view, typically from a nib.

        
    @IBAction func btnTapped(_ sender: Any) {
        myVariable = myVariable - 1
        label.text = String(myVariable)
    }
    
    @IBAction func screenlock(_ sender: Any) {
        if(tempLock == true){
       self.label.isUserInteractionEnabled = false
            self.saveButton.isUserInteractionEnabled = false
            self.resetButton.isUserInteractionEnabled = false
            self.UndoButton.isUserInteractionEnabled = false
            
            label.text = "locked"
            lockButton.setTitle("Locked", for: UIControlState.normal)
            tempLock = false
        }
        else{
        self.label.isUserInteractionEnabled = true
            self.saveButton.isUserInteractionEnabled = true
            self.resetButton.isUserInteractionEnabled = true
            self.UndoButton.isUserInteractionEnabled = true
            
        label.text = "unlocked"
             lockButton.setTitle("Lock", for: UIControlState.normal)
        tempLock = true
        }
    }
    
    @IBAction func saveAction(_ sender: Any) {
        
      /* let storyBoard : UIStoryboard = UIStoryboard(name: "Main", bundle:nil)
        
        let nextViewController = storyBoard.instantiateViewController(withIdentifier: "secondStoryboardId") as! SecondViewController
        self.present(nextViewController, animated:true, completion:nil)*/
    } 
    
   
    
    @IBAction func ResetAction(_sender: UIButton) {
    //self.label.isUserInteractionEnabled = true
        label.text =  "0"
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        
        
        
        
        // Dispose of any resources that can be recreated.
    }


}

